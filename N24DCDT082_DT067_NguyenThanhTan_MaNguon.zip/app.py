"""DT067 — Trực quan hóa tính giá trị biểu thức hậu tố bằng ngăn xếp."""
from __future__ import annotations

import html
import re
from typing import Any

import pandas as pd
import streamlit as st


TRACE_COLUMNS = ["Bước", "Token", "Thao tác", "b (Phải)", "a (Trái)", "Phép tính", "Stack sau thao tác", "Ghi chú"]
MAX_TOKENS = 50
MAX_INPUT_ABS = 100
MAX_EXPONENT = 10
INT128_MIN = -(2 ** 127)
INT128_MAX = (2 ** 127) - 1
TEST_CASES = [
    ("VD01", "5 6 2 + * 12 4 / -", 37),
    ("VD02", "2 3 2 ^ ^", 512),
    ("TK01", "8 3 -", 5),
    ("TK02", "3 8 -", -5),
    ("BIEN01", "7 2 /", 3),
    ("BIEN02", "0 7 - 2 /", -3),
    ("BIEN03", "100 0 ^", 1),
    ("LOI01", "4 0 /", "Lỗi chia cho 0"),
    ("KT09", "1 +", "Lỗi thiếu toán hạng"),
    ("KT10", "2 3", "Lỗi dư toán hạng"),
    ("KT11", "2 x +", "Lỗi token không hợp lệ"),
    ("KT12", "100 10 ^ 100 10 ^ *", "Lỗi tràn Int128"),
]

CASE_LABELS = {
    "VD01": "Ví dụ phiếu · 37",
    "VD02": "Lũy thừa phải · 512",
    "TK01": "Trừ · 5",
    "TK02": "Kết quả âm · -5",
    "BIEN01": "Chia dương · 3",
    "BIEN02": "Chia âm · -3",
    "BIEN03": "Số mũ 0 · 1",
    "LOI01": "Chia cho 0 · lỗi",
    "KT09": "Thiếu toán hạng · lỗi",
    "KT10": "Dư toán hạng · lỗi",
    "KT11": "Token sai · lỗi",
    "KT12": "Tràn Int128 · lỗi",
}

# Danh sách mẫu luôn lấy trực tiếp từ cùng bộ dữ liệu với bảng kiểm thử,
# tránh trường hợp dropdown và 12 ca trên dashboard bị lệch nhau.
EXAMPLES = {
    f"{case_id} · {CASE_LABELS[case_id]}": expression
    for case_id, expression, _expected in TEST_CASES
}
EXAMPLES.update({
    "Giáo trình Ví dụ 5.3 · kết quả 9": "3 4 2 * + 1 1 + -",
    "Giáo trình Ví dụ 5.3 · kết quả 15": "2 3 + 4 1 - *",
})


def trunc_div(a: int, b: int) -> int:
    """Chia số nguyên cắt về 0 chính xác, không chuyển sang Float64."""
    if b == 0:
        raise ZeroDivisionError("Chia cho 0.")
    q = abs(a) // abs(b)
    return -q if (a < 0) != (b < 0) else q


def infix_to_postfix(expression: str) -> str:
    """Convert a conventional infix expression to postfix without eval().

    Supports non-negative integer operands, parentheses and + - * / ^.
    Exponentiation is right-associative, matching the DT067 postfix examples.
    """
    compact = re.sub(r"\s+", "", expression)
    tokens = re.findall(r"\d+|[()+\-*/^]", compact)
    if not compact or "".join(tokens) != compact:
        raise ValueError("Biểu thức trung tố có ký tự không hợp lệ. Dùng số nguyên, ngoặc và + - * / ^.")

    precedence = {"+": 1, "-": 1, "*": 2, "/": 2, "^": 3}
    output: list[str] = []
    operators: list[str] = []
    expecting_operand = True
    for token in tokens:
        if token.isdigit():
            if not expecting_operand:
                raise ValueError("Thiếu toán tử giữa hai số trong biểu thức trung tố.")
            output.append(token)
            expecting_operand = False
        elif token == "(":
            if not expecting_operand:
                raise ValueError("Thiếu toán tử trước dấu ngoặc mở.")
            operators.append(token)
        elif token == ")":
            if expecting_operand:
                raise ValueError("Thiếu toán hạng trước dấu ngoặc đóng.")
            while operators and operators[-1] != "(":
                output.append(operators.pop())
            if not operators:
                raise ValueError("Dấu ngoặc đóng không có ngoặc mở tương ứng.")
            operators.pop()
            expecting_operand = False
        else:
            if expecting_operand:
                raise ValueError(f"Thiếu toán hạng trước toán tử '{token}'.")
            while operators and operators[-1] != "(":
                top = operators[-1]
                if precedence[top] > precedence[token] or (precedence[top] == precedence[token] and token != "^"):
                    output.append(operators.pop())
                else:
                    break
            operators.append(token)
            expecting_operand = True

    if expecting_operand:
        raise ValueError("Biểu thức trung tố chưa có toán hạng cuối.")
    if "(" in operators:
        raise ValueError("Thiếu dấu ngoặc đóng trong biểu thức trung tố.")
    output.extend(reversed(operators))
    return " ".join(output)


def normalize_expression(expression: str, mode: str = "Tự nhận dạng") -> str:
    """Return postfix tokens for any supported input mode."""
    if mode == "Hậu tố":
        return expression
    if mode == "Trung tố (tự chuyển)":
        return infix_to_postfix(expression)
    try:
        return infix_to_postfix(expression)
    except ValueError:
        # If it is not valid infix, try it as whitespace-delimited postfix.
        return expression


def evaluate_postfix_with_trace(bt_string: str) -> dict[str, Any]:
    """Đánh giá hậu tố, trả kết quả, stack sau mỗi bước và lịch sử lần vết.

    Token là số nguyên (có thể có dấu) hoặc một trong + - * / ^. Khi gặp
    toán tử, pop b (phải) trước, rồi pop a (trái), đúng quy ước DT067.
    """
    tokens = bt_string.split()
    if not tokens:
        raise ValueError("Biểu thức đang rỗng. Hãy nhập các token cách nhau bằng khoảng trắng.")
    if len(tokens) > MAX_TOKENS:
        raise ValueError(f"Biểu thức có {len(tokens)} token; giới hạn của phiếu là {MAX_TOKENS}.")

    stack: list[int] = []
    trace: list[dict[str, Any]] = []
    snapshots: list[list[int]] = [[]]
    for step, token in enumerate(tokens, start=1):
        if re.fullmatch(r"[+-]?\d+", token):
            value = int(token)
            if abs(value) > MAX_INPUT_ABS:
                raise ValueError(f"Số đầu vào '{token}' ngoài miền -100..100 (mở rộng số âm tùy chọn) tại bước {step}.")
            stack.append(value)
            operation, b, a, calculation, note = "Đẩy số vào ngăn xếp", "—", "—", f"push({value})", "Số nguyên hợp lệ"
        elif token in {"+", "-", "*", "/", "^"}:
            if len(stack) < 2:
                raise ValueError(f"Thiếu toán hạng tại token '{token}' (bước {step}): cần 2 số, stack hiện có {len(stack)}.")
            b = stack.pop()  # Toán hạng phải được lấy trước.
            a = stack.pop()  # Toán hạng trái được lấy sau.
            if token == "+":
                value, calculation = a + b, f"{a} + {b} = {a + b}"
            elif token == "-":
                value, calculation = a - b, f"{a} - {b} = {a - b}"
            elif token == "*":
                value, calculation = a * b, f"{a} × {b} = {a * b}"
            elif token == "/":
                if b == 0:
                    raise ZeroDivisionError(f"Chia cho 0 tại bước {step}: {a} / {b}.")
                value = trunc_div(a, b)  # C++/Julia semantics, không dùng Float64.
                calculation = f"{a} / {b} = {value} (cắt về 0)"
            else:
                if b < 0:
                    raise ValueError(f"Số mũ âm không được hỗ trợ với kiểu số nguyên tại bước {step}.")
                if b > MAX_EXPONENT:
                    raise ValueError(f"Số mũ {b} ngoài miền 0..{MAX_EXPONENT} tại bước {step}.")
                value, calculation = a ** b, f"{a} ^ {b} = {a ** b}"
            if value < INT128_MIN or value > INT128_MAX:
                raise OverflowError(f"Tràn Int128 tại bước {step}: phép tính '{calculation}'.")
            stack.append(value)
            operation = "Lấy b trước, lấy a sau; tính a op b; đẩy kết quả"
            note = "b là toán hạng phải; a là toán hạng trái"
        else:
            raise ValueError(f"Token không hợp lệ '{token}' tại bước {step}. Chỉ chấp nhận số nguyên và + - * / ^.")

        trace.append({"Bước": step, "Token": token, "Thao tác": operation,
                      "b (Phải)": b, "a (Trái)": a, "Phép tính": calculation,
                      "Stack sau thao tác": "[" + ", ".join(map(str, stack)) + "]", "Ghi chú": note})
        snapshots.append(stack.copy())

    if len(stack) != 1:
        raise ValueError(f"Biểu thức dư toán hạng: sau khi đọc hết token còn {len(stack)} giá trị trên stack: {stack}.")
    return {"value": stack[0], "trace": trace, "snapshots": snapshots, "tokens": tokens}


def run_test_suite() -> pd.DataFrame:
    rows = []
    for case_id, expression, expected in TEST_CASES:
        try:
            actual: Any = evaluate_postfix_with_trace(expression)["value"]
            passed = actual == expected
            actual_display = str(actual)
        except ZeroDivisionError:
            actual_display, passed = "Lỗi chia cho 0", expected == "Lỗi chia cho 0"
        except OverflowError:
            actual_display, passed = "Lỗi tràn Int128", expected == "Lỗi tràn Int128"
        except ValueError as exc:
            actual_display = ("Lỗi thiếu toán hạng" if "Thiếu toán hạng" in str(exc)
                              else "Lỗi dư toán hạng" if "dư toán hạng" in str(exc)
                              else "Lỗi token không hợp lệ" if "Token không hợp lệ" in str(exc)
                              else f"Lỗi: {exc}")
            passed = actual_display == expected
        rows.append({"Mã ca": case_id, "Biểu thức hậu tố": expression, "Expected": expected,
                     "Actual": actual_display, "Trạng thái": "PASS" if passed else "FAIL"})
    return pd.DataFrame(rows)



def main():
    st.set_page_config(page_title="Tính giá trị biểu thức hậu tố bằng ngăn xếp", page_icon="∑", layout="wide", initial_sidebar_state="expanded")
    st.markdown("""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap');
    :root { --ink:#172554; --muted:#52627d; --line:#dce5f3; --paper:#f4f7fc; --card:#ffffff; --indigo:#4f46e5; --indigo-pale:#eef2ff; --orange:#c2410c; --green:#15803d; }
    html, body, [class*="css"] { font-family:'DM Sans', sans-serif; }
    .stApp { background:var(--paper); color:var(--ink); }
    .block-container { max-width:1420px; padding-top:2rem; padding-bottom:4rem; }
    [data-testid="stSidebar"] { background:#fff; border-right:1px solid var(--line); }
    [data-testid="stSidebar"] > div:first-child { padding-top:1.4rem; }
    h1,h2,h3 { color:var(--ink); font-family:'Manrope','DM Sans',sans-serif; letter-spacing:-.035em; }
    h1 { font-size:clamp(2rem,3.2vw,3.1rem)!important; line-height:1.1!important; }
    h2 { font-size:1.45rem!important; }
    p, label, [data-testid="stCaptionContainer"] { color:var(--muted); }
    .hero { position:relative; overflow:hidden; border:1px solid #d7ddff; border-radius:24px; padding:30px 34px; margin:0 0 20px; background:linear-gradient(118deg,#fff 0%,#f1f2ff 58%,#fff7ed 100%); box-shadow:0 10px 30px rgba(38,55,110,.06); }
    .hero:after { content:'∑'; position:absolute; right:5%; top:-42px; font:800 170px/1 'Manrope'; color:rgba(79,70,229,.08); }
    .eyebrow { display:inline-flex; align-items:center; gap:8px; border:1px solid #c7d2fe; border-radius:999px; background:#fff; padding:6px 11px; color:#3730a3; font-size:12px; font-weight:700; letter-spacing:.08em; text-transform:uppercase; }
    .hero h1 { margin:15px 0 8px; max-width:780px; }
    .hero p { margin:0; color:#475569; max-width:800px; font-size:15px; }
    .identity { margin-top:19px; display:flex; flex-wrap:wrap; gap:8px; }
    .identity span { border-radius:8px; background:rgba(255,255,255,.78); border:1px solid #e0e7ff; padding:6px 10px; color:#334155; font-size:12px; font-weight:600; }
    .section-kicker { color:#4f46e5; font-size:11px; font-weight:800; letter-spacing:.13em; text-transform:uppercase; margin-bottom:6px; }
    .metric-card { height:100%; min-height:98px; padding:16px 18px; background:#fff; border:1px solid var(--line); border-radius:16px; box-shadow:0 5px 15px rgba(38,55,110,.035); }
    .metric-label { color:#64748b; font-size:12px; font-weight:700; letter-spacing:.06em; text-transform:uppercase; }
    .metric-value { color:var(--ink); font:800 24px/1.35 'Manrope',sans-serif; margin-top:4px; overflow-wrap:anywhere; }
    .metric-note { color:#64748b; font-size:12px; }
    .panel { border:1px solid var(--line); background:var(--card); border-radius:18px; padding:20px 22px; box-shadow:0 6px 20px rgba(38,55,110,.035); height:100%; }
    .panel-title { font:700 17px 'Manrope',sans-serif; color:var(--ink); margin-bottom:3px; }
    .panel-subtitle { color:#64748b; font-size:13px; margin-bottom:17px; }
    .token-rail { display:flex; flex-wrap:wrap; gap:8px; padding:16px; border:1px solid var(--line); border-radius:14px; background:#f8faff; }
    .token { min-width:42px; text-align:center; padding:9px 12px; border:1px solid #dbe3ef; border-radius:10px; background:#fff; color:#334155; font:700 15px 'DM Sans',sans-serif; box-shadow:0 2px 4px rgba(15,23,42,.035); }
    .token.done { background:#eef2ff; border-color:#c7d2fe; color:#4338ca; }
    .token.active { background:#4f46e5; border-color:#4338ca; color:#fff; box-shadow:0 5px 12px rgba(79,70,229,.23); transform:translateY(-2px); }
    .token.operator { font-family:monospace; }
    .stack-shell { display:flex; align-items:flex-start; gap:16px; min-height:210px; padding:18px; border:1px solid #dbe3ef; border-radius:14px; background:linear-gradient(150deg,#f8faff,#eef2ff); }
    .stack-gauge { align-self:stretch; min-width:34px; display:flex; flex-direction:column; justify-content:space-between; align-items:flex-start; color:#64748b; font-size:10px; font-weight:800; letter-spacing:.08em; }
    .stack-cells { width:100%; display:flex; flex-direction:column; align-items:stretch; gap:7px; }
    .stack-cell { display:flex; align-items:center; gap:12px; min-height:38px; padding:7px 12px; border:1px solid #d6deeb; border-radius:9px; background:#fff; color:#1e293b; box-shadow:0 2px 3px rgba(15,23,42,.03); }
    .stack-cell.top { border:2px solid #6366f1; background:#eef2ff; color:#3730a3; }
    .stack-pos { width:50px; color:#64748b; font-size:10px; font-weight:800; letter-spacing:.05em; }
    .stack-val { font:800 17px 'Manrope',sans-serif; }
    .empty-stack { align-self:center; margin:auto; padding:11px 16px; border:1px dashed #b9c5d8; border-radius:10px; color:#64748b; background:#fff; font-size:13px; }
    .op-card { padding:17px; border-radius:14px; border:1px solid #fed7aa; background:#fffaf5; }
    .op-badge { color:#9a3412; background:#ffedd5; border-radius:7px; padding:5px 9px; font:800 14px 'DM Sans',sans-serif; }
    .calc { margin-top:14px; color:#7c2d12; font:700 19px 'Manrope',sans-serif; overflow-wrap:anywhere; }
    .hint { color:#64748b; font-size:12px; line-height:1.55; margin-top:8px; }
    .stButton button, .stDownloadButton button { min-height:42px; border-radius:10px; font-weight:700; transition:all .18s ease; }
    .stButton button:hover, .stDownloadButton button:hover { border-color:#6366f1; color:#3730a3; transform:translateY(-1px); }
    button:focus-visible, input:focus-visible, [role="slider"]:focus-visible { outline:3px solid #818cf8!important; outline-offset:2px!important; }
    [data-baseweb="tab-list"] { gap:8px; border-bottom:1px solid var(--line); }
    [data-baseweb="tab"] { height:48px; padding:0 16px; color:#475569; font-weight:700; }
    [aria-selected="true"][data-baseweb="tab"] { color:#4338ca; }
    div[data-baseweb="tab-highlight"] { background-color:#4f46e5!important; }
    [data-testid="stProgress"] [role="progressbar"] > div { background-color:#4f46e5!important; }
    [data-testid="stSlider"] [role="slider"] { background-color:#4f46e5!important; border-color:#4f46e5!important; box-shadow:0 0 0 3px rgba(79,70,229,.15)!important; }
    [data-testid="stDataFrame"] { border:1px solid var(--line); border-radius:12px; overflow:hidden; }
    @media(max-width:760px) { .block-container {padding:1rem 1rem 3rem;} .hero {padding:23px 20px;border-radius:18px;} .hero:after {font-size:115px;right:1%;top:0;} .panel {padding:16px;} .stack-shell {min-height:170px;} }
    @media(prefers-reduced-motion:reduce) { *,*::before,*::after {scroll-behavior:auto!important;transition:none!important;animation:none!important;} }
    </style>
    """, unsafe_allow_html=True)

    def _load_example() -> None:
        st.session_state["expression_input"] = EXAMPLES[st.session_state["example_choice_v2"]]
        st.session_state["input_mode"] = "Tự nhận dạng"

    # Use a fresh widget key because a browser tab may retain the old sample
    # labels after Streamlit hot-reloads this version of the app.
    if "example_choice_v2" not in st.session_state:
        current_expression = st.session_state.get("expression_input", "")
        st.session_state["example_choice_v2"] = next(
            (label for label, sample in EXAMPLES.items() if sample == current_expression),
            next(iter(EXAMPLES)),
        )
    st.session_state.setdefault("expression_input", EXAMPLES[st.session_state["example_choice_v2"]])
    st.session_state.setdefault("input_mode", "Tự nhận dạng")

    with st.sidebar:
        st.markdown('<div class="section-kicker">BÀI THỰC HÀNH · DT067</div>', unsafe_allow_html=True)
        st.header("Thiết lập biểu thức")
        st.selectbox("Ví dụ mẫu · 12 ca DT067", list(EXAMPLES), key="example_choice_v2", on_change=_load_example)
        st.caption("Có đủ 12 ca trong phiếu kiểm thử và 2 ví dụ giáo trình (kết quả 9, 15).")
        st.selectbox("Cách nhập", ["Tự nhận dạng", "Hậu tố", "Trung tố (tự chuyển)"], key="input_mode")
        input_label = "Biểu thức mới" if st.session_state["input_mode"] == "Tự nhận dạng" else ("Biểu thức hậu tố" if st.session_state["input_mode"] == "Hậu tố" else "Biểu thức toán học")
        input_help = ("Nhập tự do dạng 2+4*3 hoặc hậu tố 2 4 3 * +; web sẽ tự nhận dạng."
                      if st.session_state["input_mode"] == "Tự nhận dạng" else ("Ví dụ: 8 5 - 2 *. Nhập số và toán tử cách nhau bằng khoảng trắng."
                      if st.session_state["input_mode"] == "Hậu tố" else "Ví dụ: 8 - 5 * 2. Hỗ trợ ngoặc và + - * / ^."))
        expression = st.text_input(input_label, key="expression_input", help=input_help)
        st.caption("Mặc định tự nhận dạng hậu tố/trung tố. Toán hạng phải b được lấy trước khi chạy thuật toán stack.")
        st.divider()
        st.markdown("**Chạy trên máy của bạn**\n\n`pip install streamlit pandas`\n\n`streamlit run app.py`")

    st.markdown("""
    <section class="hero">
      <div class="eyebrow">INT13185 <span aria-hidden="true">·</span> ĐỒ ÁN DT067</div>
      <h1>Tính giá trị biểu thức hậu tố bằng ngăn xếp</h1>
      <p>Quan sát cách mỗi token thay đổi ngăn xếp và kiểm chứng phép tính theo quy tắc pop toán hạng phải trước.</p>
      <div class="identity"><span>Nguyễn Thành Tân</span><span>N24DCDT082</span><span>D24CQDT01-N · Nhóm 03</span><span>Chương 5 · Mục 5.3.4.2 · Ví dụ 5.3</span></div>
    </section>
    """, unsafe_allow_html=True)

    tab_trace, tab_tests, tab_about = st.tabs(["Mô phỏng lần vết", "Bộ kiểm thử · 12 ca", "Quy tắc thuật toán"])
    with tab_trace:
        try:
            postfix_expression = normalize_expression(expression, st.session_state["input_mode"])
            if postfix_expression != expression:
                st.info(f"Đã nhận biểu thức trung tố và chuyển sang hậu tố: `{postfix_expression}`")
            result = evaluate_postfix_with_trace(postfix_expression)
            step = st.slider("Bước thực thi", min_value=0, max_value=len(result["tokens"]), value=len(result["tokens"]), step=1,
                             help="Dùng bàn phím mũi tên hoặc kéo thanh trượt để xem trạng thái sau mỗi token.")
            completed = step == len(result["tokens"])
            st.markdown(f'<div class="section-kicker">TIẾN ĐỘ · {step} / {len(result["tokens"])} TOKEN</div>', unsafe_allow_html=True)
            st.progress(step / len(result["tokens"]))
            metric_cols = st.columns(3)
            metrics = [("KẾT QUẢ CUỐI", str(result["value"]), "Giá trị biểu thức"),
                       ("ĐANG XEM", f"{step} / {len(result["tokens"])}", "Token đã xử lý"),
                       ("TRẠNG THÁI", "Hoàn tất" if completed else "Đang mô phỏng", "Stack còn đúng một giá trị khi hoàn tất")]
            for col, (label, value, note) in zip(metric_cols, metrics):
                with col:
                    st.markdown(f'<div class="metric-card"><div class="metric-label">{label}</div><div class="metric-value">{html.escape(value)}</div><div class="metric-note">{note}</div></div>', unsafe_allow_html=True)

            st.markdown('<div style="height:14px"></div><div class="panel-title">Dòng token</div><div class="panel-subtitle">Đã xử lý · token hiện tại · các token tiếp theo</div>', unsafe_allow_html=True)
            token_html = []
            for i, token in enumerate(result["tokens"]):
                cls = "active" if i == step - 1 else "done" if i < step else ""
                operator = " operator" if token in {"+", "-", "*", "/", "^"} else ""
                token_html.append(f'<span class="token {cls}{operator}" aria-label="Token {i + 1}: {html.escape(token)}">{html.escape(token)}</span>')
            st.markdown('<div class="token-rail" role="list">' + "".join(token_html) + '</div>', unsafe_allow_html=True)
            st.markdown('<div style="height:18px"></div>', unsafe_allow_html=True)
            stack_col, action_col = st.columns([1.1, 1], gap="large")
            with stack_col:
                current_stack = result["snapshots"][step]
                if current_stack:
                    cells = []
                    for index, value in enumerate(reversed(current_stack)):
                        pos = "ĐỈNH" if index == 0 else f"VỊ TRÍ {index + 1}"
                        top_class = " top" if index == 0 else ""
                        cells.append(f'<div class="stack-cell{top_class}" role="listitem"><span class="stack-pos">{pos}</span><span class="stack-val">{value}</span></div>')
                    stack_content = '<div class="stack-gauge"><span>TOP</span><span>BOTTOM</span></div><div class="stack-cells">' + "".join(cells) + '</div>'
                else:
                    stack_content = '<div class="stack-gauge"><span>TOP</span><span>BOTTOM</span></div><div class="empty-stack">Chưa có giá trị · stack rỗng</div>'
                st.markdown(f'<div class="panel"><div class="panel-title">Ngăn xếp</div><div class="panel-subtitle">Trạng thái sau bước {step} · phần tử trên cùng ở đầu</div><div class="stack-shell" role="list" aria-label="Các phần tử trong ngăn xếp">{stack_content}</div></div>', unsafe_allow_html=True)
            with action_col:
                st.markdown('<div class="panel"><div class="panel-title">Diễn giải thao tác</div><div class="panel-subtitle">Thứ tự lấy toán hạng của đề tài DT067</div>', unsafe_allow_html=True)
                if step:
                    row = result["trace"][step - 1]
                    st.markdown(f'<div class="op-card"><span class="op-badge">TOKEN {step} · {html.escape(str(row["Token"]))}</span><div class="calc">{html.escape(str(row["Phép tính"]))}</div><div class="hint">{html.escape(str(row["Thao tác"]))}</div><div class="hint">b (phải) = <strong>{html.escape(str(row["b (Phải)"]))}</strong> &nbsp; · &nbsp; a (trái) = <strong>{html.escape(str(row["a (Trái)"]))}</strong></div></div>', unsafe_allow_html=True)
                else:
                    st.markdown('<div class="op-card"><span class="op-badge">SẴN SÀNG</span><div class="calc">Bắt đầu với stack rỗng</div><div class="hint">Kéo thanh tiến độ để bắt đầu mô phỏng từng token.</div></div>', unsafe_allow_html=True)
                st.markdown('<div class="hint">Phép toán luôn tính theo thứ tự <strong>a op b</strong>. Với phép chia, kết quả được cắt về 0 như C++/Julia.</div></div>', unsafe_allow_html=True)

            st.markdown('<div style="height:22px"></div><div class="panel-title">Bảng lần vết</div><div class="panel-subtitle">Bảng đầy đủ thuận tiện đối chiếu và đưa vào báo cáo.</div>', unsafe_allow_html=True)
            trace_df = pd.DataFrame(result["trace"], columns=TRACE_COLUMNS)
            # Keep mixed number/text fields consistent for Streamlit's Arrow table renderer.
            trace_df[["b (Phải)", "a (Trái)"]] = trace_df[["b (Phải)", "a (Trái)"]].astype(str)
            st.dataframe(trace_df, width="stretch", hide_index=True)
            download_csv, download_md, spacer = st.columns([1, 1, 4])
            with download_csv:
                st.download_button("Tải bảng CSV", trace_df.to_csv(index=False).encode("utf-8-sig"), file_name="lan_vet_hau_to.csv", mime="text/csv", width="stretch")
            markdown = "| " + " | ".join(TRACE_COLUMNS) + " |\n|" + "|".join(["---"] * len(TRACE_COLUMNS)) + "|\n"
            for _, row in trace_df.iterrows():
                markdown += "| " + " | ".join(str(row[col]).replace("|", "\\|") for col in TRACE_COLUMNS) + " |\n"
            with download_md:
                st.download_button("Tải bảng Markdown", markdown.encode("utf-8"), file_name="lan_vet_hau_to.md", mime="text/markdown", width="stretch")
        except (ValueError, ZeroDivisionError, OverflowError) as exc:
            if "dư toán hạng" in str(exc):
                st.warning("Chưa thể tính vì biểu thức có các số chưa được nối bằng toán tử. "
                           "Ví dụ trung tố: `2 + 4 * 3`; ví dụ hậu tố: `2 4 3 * +`.")
            else:
                st.error(str(exc))
                st.caption("Web vẫn hoạt động; kiểm tra toán tử và dấu ngoặc. Ví dụ `2 + 4 * 3` cho kết quả 14.")

    with tab_tests:
        st.markdown('<div class="section-kicker">CHẤT LƯỢNG THUẬT TOÁN</div>', unsafe_allow_html=True)
        st.header("Bộ kiểm thử DT067")
        st.caption("12 ca bao gồm ví dụ giáo trình, phép trừ thứ tự, chia số âm, số mũ và tình huống lỗi.")
        tests_df = run_test_suite()
        tests_df[["Expected", "Actual"]] = tests_df[["Expected", "Actual"]].astype(str)
        passed_count = int((tests_df["Trạng thái"] == "PASS").sum())
        total_cols = st.columns([1, 1, 3])
        total_cols[0].metric("Ca đạt", f"{passed_count}/{len(tests_df)}")
        total_cols[1].metric("Ca lỗi", len(tests_df) - passed_count)
        total_cols[2].markdown('<div class="hint" style="padding-top:14px">Màu trạng thái luôn đi kèm nhãn PASS/FAIL để dễ đọc và không phụ thuộc riêng vào màu sắc.</div>', unsafe_allow_html=True)
        st.dataframe(tests_df, width="stretch", hide_index=True)
        st.download_button("Tải kết quả kiểm thử CSV", tests_df.to_csv(index=False).encode("utf-8-sig"), file_name="ket_qua_kiem_thu_DT067.csv", mime="text/csv")

    with tab_about:
        st.markdown('<div class="section-kicker">CÁCH ĐỌC STACK</div>', unsafe_allow_html=True)
        st.header("Quy tắc tính hậu tố")
        st.markdown("""
        <div class="panel">
          <div class="panel-title">Một lượt xử lý toán tử</div>
          <div class="panel-subtitle">Lấy hai giá trị trên đỉnh stack theo thứ tự đề tài yêu cầu.</div>
          <div class="op-card"><span class="op-badge">1 · POP b</span><div class="hint">Phần tử đầu tiên lấy khỏi stack là toán hạng <strong>phải</strong>.</div></div>
          <div style="height:10px"></div><div class="op-card"><span class="op-badge">2 · POP a</span><div class="hint">Phần tử tiếp theo là toán hạng <strong>trái</strong>.</div></div>
          <div style="height:10px"></div><div class="op-card"><span class="op-badge">3 · TÍNH a op b</span><div class="hint">Đẩy kết quả trở lại stack; khi kết thúc phải còn đúng một giá trị.</div></div>
        </div>
        """, unsafe_allow_html=True)
        st.markdown("- **Chia nguyên:** phép chia số nguyên cắt về 0, không chuyển qua số thực; `-7 / 2 = -3`.\n- **Lũy thừa:** `^` kết hợp phải; `2 3 2 ^ ^` tương ứng `2 ^ (3 ^ 2) = 512`.\n- **Nhập trung tố:** ứng dụng tự chuyển biểu thức toán học có ngoặc sang hậu tố trước khi chạy cùng thuật toán stack.\n- **Validator:** phát hiện token không hợp lệ, thiếu/dư toán hạng, chia cho 0 và tràn.")

if __name__ == "__main__":
    main()
