Thư mục ảnh minh chứng theo yêu cầu của hướng dẫn nộp INT13185.
Chưa có ảnh nào được tạo trong bản nháp này; không dùng ảnh giả làm bằng chứng.

Cần chụp ảnh thật, đọc được, cho từng mục:
A01  Ví dụ 1 phiếu: 5 6 2 + * 12 4 / -
A02  Ví dụ 2 phiếu: 2 3 2 ^ ^
A03  Ca TK01: 8 3 -
A04  Ca TK02: 3 8 -
A05  Ca BIEN01: 7 2 /
A06  Ca BIEN02: 0 7 - 2 /
A07  Ca BIEN03: 100 0 ^
A08  Input lỗi, gắn với một trong KT09–KT12
A09  Tổng kết bộ kiểm thử ít nhất 12 ca
A10  Clone SHA C trong thư mục mới và chạy lại
A11  Repo GitHub thật, commit C và permalink mã/test

Lưu ảnh gốc tại đây với tên tương ứng, rồi chèn đủ 11 ảnh vào báo cáo.
