# DT067 — Tính giá trị biểu thức hậu tố bằng ngăn xếp

**Sinh viên:** Nguyễn Thành Tân · **MSSV:** N24DCDT082 · **Lớp:** D24CQDT01-N · **Nhóm:** 03  
**Học phần:** INT13185 · **Giảng viên:** Hồ Nhựt Minh

## Trạng thái bản làm

Đây là bản nộp nháp để tiếp tục hoàn thiện. Chức năng chính và 12 ca kiểm thử đang có; cần bổ sung ảnh thực thi cá nhân, URL GitHub/SHA, chạy lại từ bản clone sạch và hoàn tất báo cáo theo khung trước khi nộp.

## Phạm vi theo phiếu DT067

Ứng dụng đánh giá biểu thức hậu tố số nguyên bằng stack; toán tử `+ - * / ^`; lấy toán hạng phải `b` trước, toán hạng trái `a` sau rồi tính `a op b`. Biểu thức có tối đa 50 token; số đầu vào thuộc `0..100`, số mũ thuộc `0..10`; có kiểm tràn Int128, chia cho 0, thiếu toán hạng, dư toán hạng và token không hợp lệ. Phiếu cho phép mở rộng token số âm; chương trình nhận số âm trong miền `-100..-1` mà không thêm dấu âm đơn ngôi.

Phép chia cắt về 0, không qua số thực: `-7 / 2 = -3`. Lũy thừa dùng kết hợp từ phải sang trái theo thứ tự biểu thức hậu tố: `2 3 2 ^ ^ = 512`.

## Cài đặt và chạy

Yêu cầu Python 3.12 trở lên. Từ thư mục có `app.py`:

```bash
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# macOS/Linux:
# source .venv/bin/activate
python -m pip install -r requirements.txt
streamlit run app.py
```

Nhập biểu thức mới ở thanh bên hoặc chọn một ví dụ mẫu. Mặc định **Tự nhận dạng** chấp nhận cả biểu thức toán học thông thường và hậu tố; dùng thanh bước để xem stack và bảng lần vết.

Ví dụ `2 + 4 * 3` được tự chuyển thành `2 4 3 * +` rồi tính ra `14`. Có thể chọn **Hậu tố** hoặc **Trung tố (tự chuyển)** để khóa cách nhập; danh sách mẫu chỉ là gợi ý, không giới hạn biểu thức được nhập.

## Ví dụ trên phiếu

```text
5 6 2 + * 12 4 / -  ->  37
2 3 2 ^ ^            ->  512
```

## Chạy bộ kiểm thử

```bash
python -m unittest -v test_postfix.py
```

Bộ kiểm thử gồm hai ví dụ trên phiếu, đủ năm ca bắt buộc, hai ca lỗi bổ sung và các kiểm tra biên/overflow để đạt 12 ca độc lập. Kết quả mong đợi và thực tế được xác định trong `test-results.txt` sau khi chạy.

## Thành phần trong ZIP

- `app.py`: ứng dụng Streamlit, thuật toán và giao diện.
- `test_postfix.py`: 12 ca kiểm thử tự động.
- `requirements.txt`: thư viện cần cài.
- `test-results.txt`: log kiểm thử của bản nháp.
- `docs/anh_ket_qua/`: chỗ lưu ảnh gốc. **11 ảnh theo hướng dẫn môn học chưa được bổ sung trong bản nháp này.** Tên và mục đích từng ảnh được liệt kê trong README của thư mục.

Không đưa `.git`, cache, `.venv`, gói cài hoặc thư mục `.pydeps` vào ZIP. Sau khi bổ sung ảnh, hãy cập nhật GitHub, ghi SHA C/S thật trong TXT nộp và clone SHA S vào thư mục mới để chạy lại.
